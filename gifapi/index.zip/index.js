console.log('Loading function');

const aws = require('aws-sdk');
const mysql = require('mysql');
const convertapi = require('convertapi')('n2QH0QA4agOZTghF');

const s3 = new aws.S3({ apiVersion: '2006-03-01' });
//4 lines of code to get one datetime, yes
const today = new Date();
const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
const dateTime = date + ' ' + time;

const request = require('request')

//obfuscate "sensitive" data
const con = mysql.createConnection({
    host: "rdsgif.cdaqwx2yziup.us-east-1.rds.amazonaws.com",
    user: "admin",
    password: "bighentaiboobz",
    multipleStatements: true
});

const gifApi = async (urlArray) => {
    await convertapi.convert('gif', {
    Files: urlArray,
}, 'png').catch(function (err) {console.error(err.toString())}).
    then(function(result) {
    if(JSON.stringify(result) === JSON.stringify({})) {
        console.log("empty response")
        gifApi(urlArray)
    }
    else {return result}
})
    }

exports.handler = async(event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    const urlArray = [];
    const bucket = "ictarchitectuur"
    //const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const sub = event.detail.sub
    const listParams = {
        Bucket: bucket,
        Prefix: sub
    };
    //list objects in bucket/sub/directory
    const listedObjects = await s3.listObjectsV2(listParams).promise();
    //get presigned urls for all images to convert
    if (listedObjects.Contents.length !== 0 ) {
        console.log("getting images from bucket")
        for (const {Key} of listedObjects.Contents) {
            const url = await s3.getSignedUrl('getObject', {
                Bucket: bucket,
                Key: Key,
                Expires: 86400,
            })
            urlArray.push(url)
        } //convert PNGS to GIF
            console.log("converting images to gif")
            const result = gifApi(urlArray)
            console.log(result)

            //get gif and download from the url
                request({
                    uri: result.files[0].url,
                    encoding: null
                }, function(error, response , body) {

                    console.log("storing gif in bucket")
                    s3.putObject({
                        Body: body,
                        Key: `gifs/${sub}/${result.files[0].fileName}`,
                        Bucket: bucket
                    }, function(error, data) {
                        if (error) {
                            console.log("error downloading gif to s3");
                        } else { // store sub, gif name and dateTime in RDS
                            console.log("success uploading to s3");

                            con.connect(function(err) {
                                if (err) throw err;
                                con.query(`use gif_dev; INSERT INTO GifApi (TIMEDATE, SUB, fileName) VALUES ("${dateTime}", "${sub}", "${result.files[0].fileName}");`, function (err, result, fields) {
                                    con.release();
                                    if (err) throw err;
                                    console.log(result);
                                });
                            });

                        }
                    });
                })
    }
    else console.log("listedObjects of directory was 0")
};
