const mysql = require('mysql');
const aws = require('aws-sdk');

const s3 = new aws.S3({ apiVersion: '2006-03-01' });

const con = mysql.createConnection({
    host: "rdsgif.cdaqwx2yziup.us-east-1.rds.amazonaws.com",
    user: "admin",
    password: "bighentaiboobz",
    multipleStatements: true
});

exports.handler = async(event, context) => {


        await con.connect(function(err) {
        if (err) throw err;
        con.query(`use gif_dev;
                   select  CONCAT("gifs/", SUB,"/", fileName) as gifPath from GifApi
                   where hour(timediff( CURRENT_TIMESTAMP, timedate )) > 24;
                   SET SQL_SAFE_UPDATES = 0;
                   delete from GifApi
                   where hour(timediff( CURRENT_TIMESTAMP, timedate )) > 24;
                   SET SQL_SAFE_UPDATES = 1;`,
            function (err, result, fields) {
                con.release();
                if (err) throw err;
                console.log(fields)
                console.log(result);

        });
    });
    }